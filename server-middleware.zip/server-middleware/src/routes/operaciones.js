const { Router } = require('express');//Se especifica el metodo Router de Express
const router = Router();


router.post("/suma", (req,res) => {
    var { num1,num2 } = req.body;
    var suma = num1+num2;
    const respuesta = {
        "resultado": suma
    }
    res.json(respuesta)
})

router.post("/resta", (req, res)=>{
    var {num1, num2 } = req.body;
    var resta = num1-num2;
    const respuesta = {
        "resultado": resta
    }
    res.json(respuesta)
})

router.post("/multiplicacion", (req, res)=>{
    var {num1, num2 } = req.body;
    var multi = num1*num2;
    const respuesta = {
        "resultado": multi
    }
    res.json(respuesta)
})

router.post("/division", (req, res)=>{
    var {num1, num2 } = req.body;
    var division = num1/num2;
    const respuesta = {
        "resultado": division
    }
    res.json(respuesta)
})

module.exports=router;

